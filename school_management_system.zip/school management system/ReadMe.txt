guidelines:
first thing first

1. create database (sms2.sql)
2. import sms2.sql

part 1 done!!!!

3. paste the sms folder in the www folder of whichever server ypu are using.
4. congatulations!!

************************************************************
The sms or email section kinldy contact +254729734768 wazup only for guidelines.
you are required to pay $53 before any help is rendered.

wishing ypu well